package com.Viagra.Utils;

public class TimerUtils {
	
	public long lastMs;
	
	public TimerUtils() {
		this.reset();
	}
	
	public boolean check(long ms) {
		return (getCurrentMs() - this.lastMs) >= ms;
	}
	
	public long getCurrentMs() {
		return System.nanoTime() / 1000000L;
	}
	
	public void reset() {
		this.lastMs = getCurrentMs();
	}
}
