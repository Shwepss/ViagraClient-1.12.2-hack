package com.Viagra;

import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;

public class CommandManager {
	
	public static String prefix = "[ViagraClient] ";
	
	public void onCommand(String cmd) {
		Minecraft mc = Minecraft.getMinecraft();
		try {
		
				if(cmd.contains(".help")) {
					showMessage("====ViagraClient help====");
					showMessage(".motionY <сила> - подкинет вас");
					showMessage(".say <сообщение> - отправит сообщение в чат");
					
				}
				if(cmd.contains(".motionY ")) {
					double y = Double.parseDouble(cmd.split(".motionY ")[1]);
					mc.player.motionY += y;
					showMessage("Вас подкинуло с силой " + y);
				}
				if(cmd.contains(".say ")) {
					String msg = cmd.split(".say ")[1];
					mc.player.sendChatMessage(msg);
				}
				

		} catch (Exception eg) {
			eg.printStackTrace();
			showMessage(eg.getMessage());
		}
	}
	
	public static void showMessageWithPrefix(String text) {
		Minecraft mc = Minecraft.getMinecraft();
		mc.ingameGUI.getChatGUI().printChatMessage(new TextComponentString(prefix + text));
	}
	
	public static void showMessage(String text) {
		Minecraft mc = Minecraft.getMinecraft();
		mc.ingameGUI.getChatGUI().printChatMessage(new TextComponentString(text));
	}
	
	
	
	
	
	
}
