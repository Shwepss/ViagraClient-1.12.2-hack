package com.Viagra.Modules;

import java.awt.Color;
import java.util.Random;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import com.Viagra.ViagraClient;
import com.Viagra.ModuleSystem.Module;
import com.Viagra.ModuleSystem.ModuleType;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;

public class HudHack extends Module {

	public static Module mod;
	public HudHack() {
		super("HUD-Array", Keyboard.KEY_NONE, ModuleType.Render);
		mod = this;
	}
	
	public void onRender2D() {
		Minecraft mc = Minecraft.getMinecraft();
		ScaledResolution sr = new ScaledResolution(mc);
		GL11.glPushMatrix();
		String serverIp = "";
		int height = 2;
		Gui.drawRect(0, 0, serverIp.length() + 120, 32, Color.black.hashCode() * 100);
		mc.fontRendererObj.drawStringWithShadow(ViagraClient.clientName, 2, height, 0xfffbbbff);
		mc.fontRendererObj.drawStringWithShadow("Nickname: "  + mc.getSession().getUsername(), 2, height = height + 10, 0xfffbbbff);

		if(!mc.isSingleplayer()) {
			serverIp = mc.getCurrentServerData().serverIP;
			mc.fontRendererObj.drawStringWithShadow("Server IP: "  + serverIp, 2, height = height + 10, 0xfffbbbff);
		} else {
			mc.fontRendererObj.drawStringWithShadow("Server IP: integrated server", 2, height = height + 10, 0xfffbbbff);
		}
		
		for(Module m : ViagraClient.manager.getModules()) {
			if(m.isEnabled()) {
				height = height + 10;
				mc.fontRendererObj.drawStringWithShadow(m.getName(), 2, height, m.getName().length() * 1000000);
			}
		}
		
		GL11.glColor4f(1f, 1f, 1f, 1f);
		GL11.glPopMatrix();
	}
}
