package com.Viagra.Modules;

import org.lwjgl.input.Keyboard;

import com.Viagra.ModuleSystem.Module;
import com.Viagra.ModuleSystem.ModuleType;

public class AntiKnockBack extends Module {
	
	public static AntiKnockBack akb;
	public AntiKnockBack() {
		super("AntiKnockBack", Keyboard.KEY_R, ModuleType.Player);
		akb = this;
	}

}
