package com.Viagra.Modules;

import org.lwjgl.input.Keyboard;

import com.Viagra.ModuleSystem.Module;
import com.Viagra.ModuleSystem.ModuleType;
import com.Viagra.Utils.TimerUtils;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;

public class KillAura extends Module {

	public TimerUtils time;
	public Minecraft mc = Minecraft.getMinecraft();
	
	public KillAura() {
		super("ViAura", Keyboard.KEY_R, ModuleType.Player);
	}
	
	public void onEnable() {
		this.time = new TimerUtils();
	}
	
	public void onDisable() {
	}
	
	public void onUpdate() {
		for (Entity ent : mc.world.loadedEntityList) {
			if (ent instanceof EntityPlayer) {
				if (ent != mc.player && mc.player.getDistanceToEntity(ent) <= 5 && time.check(500L)) {
					mc.playerController.attackEntity(mc.player, ent);
					mc.player.swingArm(EnumHand.MAIN_HAND);
					time.reset();
				}
			}
		}
	}
	
}
