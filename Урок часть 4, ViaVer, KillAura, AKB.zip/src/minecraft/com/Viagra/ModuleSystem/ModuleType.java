package com.Viagra.ModuleSystem;

public enum ModuleType {
	Player, Exploit, Render, Fun
}
