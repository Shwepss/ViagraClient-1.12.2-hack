package com.Viagra.Modules;

import org.lwjgl.input.Keyboard;

import com.Viagra.ModuleSystem.Module;
import com.Viagra.ModuleSystem.ModuleType;

import net.minecraft.client.Minecraft;

public class BrightHack extends Module {

	public BrightHack() {
		super("BrightHack", Keyboard.KEY_O, ModuleType.Render);
	}
	
	float gamma;
	
	public void onEnable() {
		Minecraft mc = Minecraft.getMinecraft();
		gamma = mc.gameSettings.gammaSetting;
		mc.gameSettings.gammaSetting = 1000000f;
	}
	
	public void onDisable() {
		Minecraft mc = Minecraft.getMinecraft();
		mc.gameSettings.gammaSetting = gamma;
	}
}
