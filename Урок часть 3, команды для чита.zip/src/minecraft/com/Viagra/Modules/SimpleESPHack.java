package com.Viagra.Modules;

import org.lwjgl.input.Keyboard;

import com.Viagra.ModuleSystem.Module;
import com.Viagra.ModuleSystem.ModuleType;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class SimpleESPHack extends Module {

	public SimpleESPHack() {
		super("SimpleESPHack", Keyboard.KEY_X, ModuleType.Render);
	}
	
	public void onEnable() {
		
	}
	
	public void onDisable() {
		Minecraft mc = Minecraft.getMinecraft();
		for(Entity ent : mc.world.loadedEntityList) {
			if(ent instanceof EntityPlayer && ent != mc.player) {
				ent.setGlowing(false);
			}
		}
	}
	
	public void onUpdate() {
		Minecraft mc = Minecraft.getMinecraft();
		for(Entity ent : mc.world.loadedEntityList) {
			if(ent instanceof EntityPlayer && ent != mc.player) {
				ent.setGlowing(true);
			}
		}
		
	}
}
