package com.Viagra;

import org.lwjgl.opengl.Display;

import com.Viagra.ModuleSystem.Module;
import com.Viagra.ModuleSystem.ModuleLoader;
import com.Viagra.Modules.HudHack;

import net.minecraft.client.Minecraft;

public class ViagraClient {

	public static String clientName = "ViagraClient V0.1";
	public static ModuleLoader manager;
	public static Minecraft mc;
	
	public void startClient(Minecraft minecraft) {
		mc = minecraft;
		manager = new ModuleLoader();
		manager.loadModules();
		autoStart();
	}
	
	public void autoStart() {
		HudHack.mod.toggle();
	}
	
	public ModuleLoader mLoader() {
		return manager;
	}
	
	public static void onKeyPress(int bind) {
		for(Module m : manager.getModules()) {
			if(m.getBind() == bind) {
				m.toggle();
			}
		}
	}
}
