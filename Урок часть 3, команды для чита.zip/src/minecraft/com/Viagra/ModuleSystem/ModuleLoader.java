package com.Viagra.ModuleSystem;

import java.util.ArrayList;

import com.Viagra.Modules.*;

public class ModuleLoader {
	
	public static ArrayList<Module> modules = new ArrayList<>();
	
	public void loadModules() {
		this.addModule(new LiftHack());
		this.addModule(new HudHack());
		this.addModule(new BrightHack());
		this.addModule(new SimpleESPHack());
		System.out.println("[ViagraClient] модули загружены!");
	}
	
	public void addModule(Module m) {
		this.modules.add(m);
	}
	
	public ArrayList<Module> getModules(){
		return this.modules;
	}
	
}
