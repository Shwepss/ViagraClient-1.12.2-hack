package net.minecraft.block.state;

public enum BlockFaceShape
{
    SOLID,
    BOWL,
    CENTER_SMALL,
    MIDDLE_POLE_THIN,
    CENTER,
    MIDDLE_POLE,
    CENTER_BIG,
    MIDDLE_POLE_THICK,
    UNDEFINED;
}
