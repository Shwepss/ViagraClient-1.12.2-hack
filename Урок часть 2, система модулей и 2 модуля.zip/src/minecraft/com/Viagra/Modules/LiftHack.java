package com.Viagra.Modules;

import org.lwjgl.input.Keyboard;

import com.Viagra.ModuleSystem.Module;
import com.Viagra.ModuleSystem.ModuleType;

import net.minecraft.client.Minecraft;

public class LiftHack extends Module {

	public LiftHack() {
		super("LiftHack", Keyboard.KEY_F, ModuleType.Player);
	}
	
	public void onUpdate() {
		Minecraft mc = Minecraft.getMinecraft();
		mc.player.jump();
	}
}
