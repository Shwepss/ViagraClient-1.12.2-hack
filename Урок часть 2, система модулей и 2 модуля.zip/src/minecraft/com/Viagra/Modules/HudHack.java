package com.Viagra.Modules;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import com.Viagra.ViagraClient;
import com.Viagra.ModuleSystem.Module;
import com.Viagra.ModuleSystem.ModuleType;

import net.minecraft.client.Minecraft;

public class HudHack extends Module {

	public static Module mod;
	public HudHack() {
		super("HUD-Array", Keyboard.KEY_NONE, ModuleType.Render);
		mod = this;
	}
	
	public void onRender2D() {
		Minecraft mc = Minecraft.getMinecraft();
		GL11.glPushMatrix();
		GL11.glScalef(1.4f, 1.4f, 1.4f);
		mc.fontRendererObj.drawStringWithShadow(ViagraClient.clientName, 2, 2, 0xfffbbbff);
		
		mc.fontRendererObj.drawStringWithShadow("==================", 2, 12, 0xfffbbbff);
		int height = 32;
		for(Module m : ViagraClient.manager.getModules()) {
			if(m.isEnabled()) {
				mc.fontRendererObj.drawStringWithShadow(m.getName(), 2, height, 0xfffbbbff);
			}
			height = height - 10;
		}
		
		GL11.glColor4f(1f, 1f, 1f, 1f);
		
		
		GL11.glPopMatrix();
	}
}
